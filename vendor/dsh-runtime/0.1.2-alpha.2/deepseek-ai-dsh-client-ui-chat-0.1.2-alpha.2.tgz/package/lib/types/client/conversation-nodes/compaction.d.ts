import type { Context } from '@deepseek-ai/cordis';
import type { ConversationMatch, ConversationNodeDefinition } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { CompactionSummaryNode } from '../contract/snapshot.ts';
declare module '../contract/chat-nodes.ts' {
    interface ChatNodeDataMap {
        /** Automatic compaction checkpoint marker. */
        compaction: CompactionSummaryNode;
    }
}
interface CompactionState {
    readonly summary?: ConversationMatch;
    readonly checkpoint?: ConversationMatch;
}
/** Automatic compaction lifecycle and landed checkpoint Definition. */
export declare const compactionDefinition: ConversationNodeDefinition<CompactionState>;
/**
 * Register the automatic-compaction business contribution.
 * @param ctx - owning UI Conversation context.
 */
export declare function registerCompactionConversationNode(ctx: Context): void;
export {};
//# sourceMappingURL=compaction.d.ts.map